## npm i ejs express mongoose dotenv debug express-session bcrypt jsonwebtoken  react-icons react-toastify express-ejs-layouts multer   express-validator cookie-parser razorpay config
## npm i jest --save-dev  socket.io redis sharp 
