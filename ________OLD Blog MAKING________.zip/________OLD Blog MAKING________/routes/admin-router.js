const express = require("express");
const router = express.Router();
const postModel = require("../models/post-model");
const { authMiddleWare } = require("../middlewares/auth-middleware");

const {
  adminController,
  createAccount,
  signUp__Page__Controller__,
  login_In_Controller,
  dashBoard__Controller,
  addPost__,
  add_Single_Post__,
  editPOST,
  updatePost,
  deletePost___,
  logoutController,
} = require("../controllers/admin-controller");

router.get("/", adminController);
router.post("/createAccount", createAccount);
router.post("/login", login_In_Controller);
router.get("/Sign-Up", signUp__Page__Controller__);

router.get("/dashboard", authMiddleWare, dashBoard__Controller);

router.get("/add-Post", authMiddleWare, addPost__);
router.post("/add-single-Post", authMiddleWare, add_Single_Post__);

router.get("/edit-posts/:id", authMiddleWare, editPOST);
router.post("/update-post/:id", authMiddleWare, updatePost);

router.post("/delete-post/:id", authMiddleWare, deletePost___);
router.post("/logout", logoutController);

module.exports = router;
