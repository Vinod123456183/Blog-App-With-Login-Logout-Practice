const express = require("express");
const router = express.Router();
const postModel = require("../models/post-model");

const {
  indexController,
  searchItemController,
  singlPostController,
  contactPage,
} = require("../controllers/index-controller");

router.get("/", indexController);
router.get("/contact", contactPage);
router.post("/search-item", searchItemController);

router.get("/singlePost/:id", singlPostController);

// function INSERT_IN_POST() {
//   const arr = [];

//   const titleWords = [
//     "Quick",
//     "Lazy",
//     "Happy",
//     "Ancient",
//     "Future",
//     "Dark",
//     "Bright",
//     "Hidden",
//     "Silent",
//     "Magic",
//   ];
//   const nouns = [
//     "Journey",
//     "Dream",
//     "Forest",
//     "City",
//     "Idea",
//     "Story",
//     "World",
//     "Path",
//     "Secret",
//     "Power",
//   ];
//   const loremSentences = [
//     "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
//     "Praesent tincidunt sed tellus ut rutrum.",
//     "Aenean quis quam porta, fermentum purus a, iaculis justo.",
//     "Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.",
//     "Pellentesque habitant morbi tristique senectus et netus et malesuada.",
//     "Donec sagittis, sapien ut mattis dictum, metus justo lacinia erat.",
//     "Curabitur vel sem at mauris viverra feugiat.",
//     "Suspendisse potenti. Etiam ac tortor ut sapien consequat lacinia.",
//     "Integer posuere lorem ut lacus volutpat, nec faucibus risus laoreet.",
//     "Nam sollicitudin sapien in justo blandit, ut lobortis ligula convallis.",
//   ];

//   for (let i = 0; i < 20; i++) {
//     const randomTitle = `${
//       titleWords[Math.floor(Math.random() * titleWords.length)]
//     } ${nouns[Math.floor(Math.random() * nouns.length)]}`;
//     const body = Array.from(
//       { length: 3 },
//       () => loremSentences[Math.floor(Math.random() * loremSentences.length)]
//     ).join(" ");

//     arr.push({
//       title: randomTitle,
//       body: body,
//     });
//   }

//   postModel
//     .insertMany(arr)
//     .then(() => {
//       console.log("20 Items Added IN DataBase");
//     })
//     .catch((err) => {
//       console.log("Error While Adding Posts", err);
//     });
// }

// INSERT_IN_POST();

module.exports = router;
