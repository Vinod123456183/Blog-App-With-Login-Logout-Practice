const postModel = require("../models/post-model");

const indexController = async (req, res) => {
  try {
    const perPage = 10;
    const page = parseInt(req.query.page) || 1;

    const details_new = await postModel
      .aggregate([{ $sort: { createdAt: -1 } }])
      .skip(perPage * (page - 1))
      .limit(perPage)
      .exec();

    const count = await postModel.countDocuments();
    const nextPage = page + 1;
    const hasNextPage = nextPage <= Math.ceil(count / perPage);

    console.log("Current page:", page);
    console.log("Skip value:", perPage * (page - 1));
    console.log("Total posts:", count);

    res.render("index", {
      details: details_new,
      current: page,
      nextPage: hasNextPage ? nextPage : null,
    });
  } catch (error) {
    console.error("Error in indexController:", error);
    res.status(500).send("Error occurred while fetching posts.");
  }
};

const searchItemController = async (req, res) => {
  let searchTerm = req.body.search;
  const regex__ = searchTerm.replace(/[^a-zA-Z0-9]/g, "");
  const data = await postModel.find({
    $or: [
      { title: { $regex: new RegExp(regex__, "i") } },
      { body: { $regex: new RegExp(regex__, "i") } },
    ],
  });
  res.render("searchItemsEJS", { data });
};

const singlPostController = async (req, res) => {
  const slug = req.params.id;
  let getdetails = await postModel.findById(slug);
  if (!getdetails) {
    return res.status(404).send("Post not found");
  }
  res.render("singlePostEJS", { getdetails });
};

const contactPage = (req, res) => {
  res.render("contact");
};

module.exports = {
  indexController,
  searchItemController,
  singlPostController,
  contactPage,
};
