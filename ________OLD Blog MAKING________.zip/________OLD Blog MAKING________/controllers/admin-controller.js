const postModel = require("../models/post-model");
const userModel = require("../models/user-model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const jwtSecret = process.env.JWT_SECRET;

const adminController = (req, res) => {
  res.render("Admin_Login_EJS");
};

const createAccount = async (req, res) => {
  try {
    const { email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
      const user = await userModel.create({
        email,
        password: hashedPassword,
      });
      res.render("userCreated_EJS");
    } catch (error) {
      if (error.code === 11000) {
        return res.status(409).json({ message: "User Already in Use" });
      }
      return res.status(500).json({ message: "Internal Server Error" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

const login_In_Controller = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await userModel.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: "No User Found" });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid Credentials" });
    }

    const token = jwt.sign({ userId: user._id }, jwtSecret);
    res.cookie("token", token, { httpOnly: true });
    res.redirect("dashboard");
  } catch (error) {
    res.status(400).json({ message: "Error" });
  }
};

const signUp__Page__Controller__ = (req, res) => {
  res.render("signup__Page__ejs"); // Make sure signup.ejs exists
};

const dashBoard__Controller = async (req, res) => {
  const data = await postModel.find().sort({ createdAt: -1 });
  res.render("dashboard", { data });
};

const addPost__ = (req, res) => {
  res.render("ADD__POST__EJS");
};

const add_Single_Post__ = async (req, res) => {
  try {
    const newPost = new postModel({
      title: req.body.title,
      body: req.body.body,
    });
    await postModel.create(newPost);
    await newPost.save();
    res.redirect("/admin/dashboard");
  } catch (error) {
    console.log("Error");
  }
};

const editPOST = async (req, res) => {
  const slug = req.params.id;
  try {
    const post = await postModel.findById(slug);
    if (!post) {
      return res.status(404).send("Post Not Found");
    }
    res.render("editPost", { post });
  } catch (error) {}
};

const updatePost = async (req, res) => {
  try {
    const postId = req.params.id;
    const updatedData = {
      title: req.body.title,
      body: req.body.body,
      updatedAt: Date.now(),
    };
    const updatedPost = await postModel.findByIdAndUpdate(postId, updatedData, {
      new: true,
    });

    if (!updatedPost) {
      return res.status(404).send("Post not found");
    }
    res.redirect("/admin/dashboard"); // Redirect to the dashboard after update
  } catch (error) {
    console.log(error);
    res.status(500).send("Error updating post.");
  }
};

const deletePost___ = async (req, res) => {
  try {
    const postId = req.params.id;
    const deletePost = await postModel.findByIdAndDelete(postId);
    if (!deletePost) {
      return res.status(404).send("Post not found");
    }
    res.redirect("/admin/dashboard");
  } catch (error) {
    console.log(error);
    res.status(500).send("There was an error deleting the post.");
  }
};

const logoutController = (req, res) => {
  // Clear authentication cookie
  res.clearCookie("token", { httpOnly: true, secure: true });

  // Check if session exists before trying to destroy it
  if (req.session) {
    req.session.destroy((err) => {
      if (err) {
        console.error("Error destroying session:", err);
        return res
          .status(500)
          .json({ message: "Failed to log out. Please try again." });
      }
      res.redirect("/"); // Redirect after successful logout
    });
  } else {
    res.redirect("/"); // If no session, just redirect
  }
};

module.exports = {
  adminController,
  createAccount,
  signUp__Page__Controller__,
  login_In_Controller,
  dashBoard__Controller,
  addPost__,
  add_Single_Post__,
  editPOST,
  updatePost,
  deletePost___,
  logoutController,
};
